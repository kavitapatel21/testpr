<?php
/**
* Plugin Name: Order-PDF
* Plugin URI: https://www.osusumeshop.jp/
* Description: osusumeshop
* Version: 0.1
* Author: osusumeshop
* Author URI: https://www.osusumeshop.jp/
**/

add_action('admin_enqueue_scripts', 'mslb_public_scripts');

function mslb_public_scripts(){
    wp_enqueue_script('custom_js', plugins_url( '/js/pdf.js', __FILE__ ), array('jquery'), '', true);
}


add_filter( 'manage_edit-shop_order_columns', 'custom_shop_order_column',11);
function custom_shop_order_column($columns)
{
    $reordered_columns = array();
    foreach( $columns as $key => $column){
        $reordered_columns[$key] = $column;
		
		
        if( $key ==  'wc_actions' ){
            $reordered_columns['my-column1'] = __( 'PDF','theme_slug');
        }
    }
    return $reordered_columns;
}

add_action( 'manage_shop_order_posts_custom_column' , 'custom_orders_list_column_content', 10, 2 );
function custom_orders_list_column_content( $column, $post_id )
{
    if( 'my-column1' == $column )
    {
      ?>
	  
	  <ul class="wpo_wcpdf-actions">
			<li>
			<a class='button exists pdf_one'   style="margin-top: 4px;"   data-id="<?php echo $post_id; ?>" href="#">見積書</a>
			<a class='button exists pdf_two'   style="margin-top: 4px;"   data-id="<?php echo $post_id; ?>" href="#" >請求書</a>
			<a class='button exists pdf_three' style="margin-top: 4px;"   data-id="<?php echo $post_id; ?>" href="#">出荷指示書</a>
			<a class='button exists pdf_four'  style="margin-top: 4px;"   data-id="<?php echo $post_id; ?>" href="#">納品書</a>
			<a class='button exists pdf_five'  style="margin-top: 4px;"   data-id="<?php echo $post_id; ?>" href="#">領収書</a>
			</li>
		</ul>
	  <?php
    }
}
