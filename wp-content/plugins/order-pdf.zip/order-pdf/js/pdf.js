
jQuery('.pdf_one').on('click', function() {
	
	var order_id = jQuery(this).attr("data-id");
	
	//alert("order_id");
	jQuery.ajax({
			url: '/wp-content/plugins/order-pdf/pdfoneajax.php',
            type: "post",   
            dataType: 'json',
            
			data: {
			order_id: order_id,
			},
            
			success:function(result){
              // alert("Here");
            }
        });
})
