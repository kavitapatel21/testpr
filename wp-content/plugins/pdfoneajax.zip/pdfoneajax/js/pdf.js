jQuery('.pdf_one').on('click', function() {
	var order_id = jQuery(this).attr("data-id");
	
	var href = myScript.pluginsUrl + '/pdfoneajax/pdfoneajax.php?order_id='+order_id;

	url = href;
	window.open(url, '_blank');
})